package br.edu.fatec.view;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import br.edu.fatec.dao.AlunoDAO;
import br.edu.fatec.model.Aluno;

public class TelaPrincipal extends JFrame {

	private JPanel contentPane;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;
	private JLabel lblCpf;
	private JLabel lblTelefone;
	private JTextField txtTelefone;
	private JTextField txtCpf;
	private JTextField txtNome;
	private JTextField txtId;
	private JButton btnNovo;
	private JButton btnSalvar;
	private JButton btnExcluir;
	private JButton btnConsultar;
	private JButton btnAlterar;
	private JButton btnListar;
	private JButton btnListar_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TelaPrincipal frame = new TelaPrincipal();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public TelaPrincipal() {
		setTitle("Cadastro de Aluno");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 767, 293);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("ID:");
		lblNewLabel.setFont(new Font("Txt_IV25", Font.PLAIN, 20));
		lblNewLabel.setBounds(31, 29, 130, 40);
		contentPane.add(lblNewLabel);
		
		lblNewLabel_1 = new JLabel("Nome:");
		lblNewLabel_1.setFont(new Font("Txt_IV25", Font.PLAIN, 20));
		lblNewLabel_1.setBounds(31, 80, 130, 40);
		contentPane.add(lblNewLabel_1);
		
		lblCpf = new JLabel("CPF:");
		lblCpf.setFont(new Font("Txt_IV25", Font.PLAIN, 20));
		lblCpf.setBounds(31, 131, 130, 40);
		contentPane.add(lblCpf);
		
		lblTelefone = new JLabel("Telefone:");
		lblTelefone.setFont(new Font("Txt_IV25", Font.PLAIN, 20));
		lblTelefone.setBounds(31, 182, 130, 40);
		contentPane.add(lblTelefone);
		
		txtTelefone = new JTextField();
		txtTelefone.setBounds(171, 182, 237, 40);
		contentPane.add(txtTelefone);
		txtTelefone.setColumns(10);
		
		txtCpf = new JTextField();
		txtCpf.setColumns(10);
		txtCpf.setBounds(171, 131, 237, 40);
		contentPane.add(txtCpf);
		
		txtNome = new JTextField();
		txtNome.setColumns(10);
		txtNome.setBounds(171, 80, 237, 40);
		contentPane.add(txtNome);
		
		txtId = new JTextField();
		txtId.setEnabled(false);
		txtId.setColumns(10);
		txtId.setBounds(171, 29, 237, 40);
		contentPane.add(txtId);
		
		btnNovo = new JButton("Novo");
		btnNovo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				txtId.setText(null);
				txtNome.setText(null);
				txtCpf.setText(null);
				txtTelefone.setText(null);
			}
		});
		btnNovo.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnNovo.setBounds(459, 29, 111, 40);
		contentPane.add(btnNovo);
		
		btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Aluno aluno = new Aluno();
				aluno.setNome(txtNome.getText());
				aluno.setCpf(txtCpf.getText());
				aluno.setTelefone(txtTelefone.getText());
				//abrir o banco
				try {
					AlunoDAO dao = new AlunoDAO();
					//SALVAR
					dao.salvar(aluno);
					JOptionPane.showMessageDialog(null, "Salvo com sucesso!");
				} catch(Exception e1){
					JOptionPane.showMessageDialog(null, "Erro "+e1.getMessage());
				}
				
			}
		});
		btnSalvar.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnSalvar.setBounds(459, 80, 111, 40);
		contentPane.add(btnSalvar);
		
		btnExcluir = new JButton("Excluir");
		btnExcluir.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnExcluir.setBounds(459, 182, 111, 40);
		contentPane.add(btnExcluir);
		
		btnConsultar = new JButton("Consultar");
		btnConsultar.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnConsultar.setBounds(583, 29, 142, 40);
		contentPane.add(btnConsultar);
		
		btnAlterar = new JButton("Alterar");
		btnAlterar.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnAlterar.setBounds(459, 131, 111, 40);
		contentPane.add(btnAlterar);
		
		btnListar = new JButton("Listar");
		btnListar.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnListar.setBounds(583, 80, 142, 40);
		contentPane.add(btnListar);
		
		btnListar_1 = new JButton("");
		btnListar_1.setIcon(new ImageIcon("C:\\Users\\aluno_lab1\\Downloads\\icons8-mulher-estudante-64.png"));
		btnListar_1.setFont(new Font("Txt_IV25", Font.PLAIN, 16));
		btnListar_1.setBounds(583, 131, 142, 91);
		contentPane.add(btnListar_1);
	}
}
